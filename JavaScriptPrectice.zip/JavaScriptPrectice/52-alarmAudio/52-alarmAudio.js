console.log('This is tutorial 52 file');
// You have to crate an alarm clock in javascript (Use your creativity)
// Allow user to set alarm for a certain time

var audio = new Audio('https://media.geeksforgeeks.org/wp-content/uploads/20190531135120/beep.mp3');
audio.play();
