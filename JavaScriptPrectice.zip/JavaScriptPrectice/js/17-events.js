console.log('moon khan');

document.getElementById('codeWithIjahar').addEventListener('click', function(e) {
    console.log('Hello Moon khan');
    console.log(e);
    // location.href = "//google.com";
    let getLoaction1 = location.href;
    console.log(getLoaction1);


});