let str = 'python';
let links = document.links;
console.log(links);
let getHref;
Array.from(links).forEach(function(element) {
    console.log(element);
    getHref = element.href;
    if (getHref.includes(str)) {
        console.log(getHref);
    }
});