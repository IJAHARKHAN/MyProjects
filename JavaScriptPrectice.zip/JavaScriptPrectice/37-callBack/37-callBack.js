console.log("This is tutorial 37");

// Pretend that this response is coming from the server
const students = [
    {name: "harry", subject: "JavaScript"},
    {name: "Rohan", subject: "Machine Learning"}
]


function enrollStudent(studentDtails, callback){
    setTimeout(function() {
     students.push(studentDtails);     
        console.log("Student has been enrolled");
        callback();
    }, 1000);
}

function getStudents(){
    setTimeout(function() {
        let str = "";
        students.forEach(function(fetchStudent){
            str += `<li> ${fetchStudent.name}</li>`
        });
        document.getElementById('students').innerHTML = str;
        console.log("Students have been fetched");
    }, 2000);
}

let newStudent = {name:"Sunny", subject:"Python"}
//enrollStudent(newStudent, getStudents);
getStudents();
